    <?php
    require_once "../PHPMailer/class.phpmailer.php"; // Download phpmailer
    if(!empty($_POST['data'])){
    $data = $_POST['data'];
    $fname = 'newpdf-'.date('d-m-Y').'.pdf'; // name the file
    $file = fopen("../pdf/" .$fname, 'w'); // open the file path
    fwrite($file, $data); //save data
    fclose($file);
    $bodytext = 'Please Find PDF';
    $email = new PHPMailer();
    $email->From = 'Booking Form';
    $email->FromName = 'My first pdf';
    $email->Subject = $file;
    $email->Body = $bodytext;
    $email->AddAddress( 'webpixlr@outlook.com' );
    //$email->AddAddress(‘person2@domain.com’, ‘Person Two’);
    //$file_to_attach = $_SERVER[‘DOCUMENT_ROOT’].’/front/pdf’;
    $email->AddAttachment('../pdf/'.$fname );

    return $email->Send();
    } else {
    echo “No Data Sent”;
    }
    ?>