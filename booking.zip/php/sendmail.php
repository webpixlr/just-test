<?php

$to="webpixlr@outlook.com";//"ganeshshrivastava81@gmail.com";
$subject="Quick contact";
$name=$_REQUEST['name'];
$phone=$_REQUEST['phone'];
$email=$_REQUEST['email'];
$msg=$_REQUEST['message'];

$message = '<html><body>';
$message .= '<div style="width:800px; border:1px solid #A3A3A3;">';
$message .= '<h1 style="color:#fff; font:normal 25px arial; background:#DA251C; padding:6px 0  6px 6px; margin:0;">Quick Contact</h1>';
$message .= '<table width="100%" border="0" cellpadding="0" cellspacing="0">';

$message .= '<tr>';
$message .='<td width="150px" valign="top" style="background:#F1F1F1; font:normal 18px Courier New; border-right:1px solid #A3A3A3;border-bottom:1px solid #A3A3A3; padding:10px;">Name</td>';
$message .='<td  width="650px" valign="top" valign="top" style="font:normal 16px arial; border-bottom:1px solid #A3A3A3; padding:10px;">'.$name.'</td>';
$message .='</tr>';

$message .= '<tr>';
$message .='<td width="150px" valign="top" style="background:#F1F1F1; font:normal 18px Courier New; border-right:1px solid #A3A3A3; border-bottom:1px solid #A3A3A3; padding:10px;">Phone</td>';
$message .='<td  width="650px" style="font:normal 16px arial; border-bottom:1px solid #A3A3A3; padding:10px;">'.$phone.'</td>';
$message .= '</tr>';


$message .= '<tr>';
$message .= '<td width="150px" valign="top" style="background:#F1F1F1; font:normal 18px Courier New; border-right:1px solid #A3A3A3; border-bottom:1px solid #A3A3A3; padding:10px;">Email</td>';
$message .= '<td width="65px" valign="top" style="font:normal 16px arial; border-bottom:1px solid #A3A3A3; padding:10px;">'.$email.'</td>';
$message .= '</tr>';
		

		

$message .= '<tr>';
$message .='<td width="150px" valign="top" style="background:#F1F1F1; font:normal 18px Courier New; border-right:1px solid #A3A3A3; padding:10px;" rowspan="3">Message</td>';
$message .='<td width="650px" valign="top" style="font:normal 16px arial;padding:10px; text-align:justify;" rowspan="3">'.$msg.'</td>';
$message .='</tr>';                    

$message .= '</table>';
$message .= '</div>';
$message .= '</body></html>';
  
	  
$headers = "MIME-Version: 1.0\r\n";
$headers .= "Content-type: text/html; charset=utf-8\r\n";
$headers .= "X-Priority: 3\r\n";
$headers .= "X-MSMail-Priority: Normal\r\n";
$headers .= "X-Mailer: php\r\n";
$headers .= "From: \"". $name ."\" <".$email.">\r\n";


mail($to, stripslashes($subject), stripslashes($message), $headers) or die("Could not send e-mail - Error A46GY7");
 
echo "<script type=\"text/javascript\">

alert('Your message has been mailed. We will contact you soon. Thank you for your mail.');

window.location='http://app-1529770455.000webhostapp.com/contact.html'

</script>";
 
?>