<?php
error_reporting(0);
// download fpdf class (http://fpdf.org)
require("../fpdf/fpdf.php");

$plotsize=$_REQUEST['plotsize'];
$plotno=$_REQUEST['plotno'];
$name=$_REQUEST['name'];
$sec_appli=$_REQUEST['sec_appli'];
$sec_son=$_REQUEST['sec_son'];
$address=$_REQUEST['address'];
$nominee=$_REQUEST['nominee'];
$state=$_REQUEST['state'];
$pincode=$_REQUEST['pincode'];
$phone=$_REQUEST['phone'];
$mobile=$_REQUEST['mobile'];
$statusRadios=$_POST['statusRadios'];
$individRadios=$_POST['individRadios'];
$occuRadios=$_POST['occuRadios'];
$schemeRadios=$_POST['schemeRadios'];
$perkatha=$_POST['perkatha'];
$plotvalue=$_POST['plotvalue'];
$bookingamount=$_POST['bookingamount'];
$bookingamountrs=$_POST['bookingamountrs'];
$payRadios=$_POST['payRadios'];
$draft=$_POST['draft'];
$bank=$_POST['bank'];
$branch=$_POST['branch'];
$date=$_POST['date'];


// fpdf object
$pdf = new FPDF();

// generate a simple PDF (for more info, see http://fpdf.org/en/tutorial/)
$pdf->AddPage();
$pdf->SetFont("Arial","I",10);
$pdf->Image('../imageforpdf/header.jpg',5,5,200);
$pdf->Image('../imageforpdf/project_info.jpg',5,40,25);
$pdf->Write(95, "Project Name : Star one           Plot Size :  $plotsize            Plot No :  $plotno           Phase :   I ");
$pdf->Ln(5);
$pdf->Image('../imageforpdf/personal_info.jpg',5,60,25);
$pdf->Write(120, "NAME : $name");
$pdf->Ln(5);
$pdf->Write(125, "SECOND APPLICANT : $sec_appli");
$pdf->Ln(5);
$pdf->Write(130, "S/O, W/O, D/O : $sec_son");
$pdf->Ln(5);
$pdf->Write(135, "ADDRESS : $address");
$pdf->Ln(5);
$pdf->Write(140, "NOMINEE : $nominee");
$pdf->Ln(5);
$pdf->Write(145, "STATE : $state         PINCODE :     $pincode ");
$pdf->Ln(5);
$pdf->Write(150, "PHONE : $phone         MOBILE :     $mobile ");
$pdf->Ln(5);
$pdf->Write(155, "STATUS : $statusRadios");
$pdf->Ln(5);
$pdf->Write(160, "IN CASE OF INDIVIDUAL : $individRadios");
$pdf->Ln(5);
$pdf->Write(165, "OCCUPATION : $occuRadios");
$pdf->Ln(5);
$pdf->Write(170, "SCHEME : $schemeRadios");
$pdf->Ln(5);
$pdf->Write(175, "PER KATHA  : $perkatha");
$pdf->Ln(5);
$pdf->Write(180, "PLOT VALUE  : $plotvalue");
$pdf->Ln(5);
$pdf->Write(185, "BOOKING AMOUNT : Rs. : $bookingamount   Rupees : $bookingamountrs");
$pdf->Ln(5);
$pdf->Write(185, "MODE OF PAYMENT : $payRadios");
$pdf->Ln(5);
$pdf->Write(185, "DRAFT : $draft");
$pdf->Ln(5);
$pdf->Write(185, "BANK : $bank");
$pdf->Ln(5);
$pdf->Write(185, "BRANCH : $branch");
$pdf->Ln(5);
$pdf->Write(185, "DATE : $date");
$pdf->Ln(15);
$pdf->Image('../imageforpdf/footer_form.jpg',5,200,200);

//$width_cell=array(25,25,25,25);
//$pdf->Cell($width_cell[0],100,'Project Name : Star City',1,0,C,false); // First column of row 1 
//$pdf->Cell($width_cell[1],100,'John Deo',1,0,C,false); // Second column of row 1 
//$pdf->Cell($width_cell[2],100,'Four',1,0,C,false); // Third column of row 1 
//$pdf->Cell($width_cell[3],100,'75',1,1,C,false); // Fourth column of row 1 


// email stuff (change data below)
$to = "manjit.subudhi@gmail.com"; //"ganeshshrivastava81@gmail.com";
$from = "Booking Form";
$subject = "Booking Form";
$message = "<p>Please see the attachment.</p>";

// a random hash will be necessary to send mixed content
$separator = md5(time());

// carriage return type (we use a PHP end of line constant)
$eol = PHP_EOL;

// attachment name
$filename = "booking.pdf";

// encode data (puts attachment in proper format)
$pdfdoc = $pdf->Output("", "S");
$attachment = chunk_split(base64_encode($pdfdoc));

// main header (multipart mandatory)
$headers  = "From: ".$from.$eol;
$headers .= "MIME-Version: 1.0".$eol;
$headers .= "Content-Type: multipart/mixed; boundary=\"".$separator."\"".$eol.$eol;


$body = "Content-Transfer-Encoding: 7bit".$eol;
$body .= "This is a MIME encoded message.".$eol.$eol;

// message
$body .= "--".$separator.$eol;
$body .= "Content-Type: text/html; charset=\"iso-8859-1\"".$eol;
$body .= "Content-Transfer-Encoding: 8bit".$eol.$eol;
$body .= $message.$eol.$eol;

// attachment
$body .= "--".$separator.$eol;
$body .= "Content-Type: application/octet-stream; name=\"".$filename."\"".$eol;
$body .= "Content-Transfer-Encoding: base64".$eol;
$body .= "Content-Disposition: attachment".$eol.$eol;
$body .= $attachment.$eol.$eol;
$body .= "--".$separator."--";

// send message
mail($to, $subject, $body, $headers);

echo "<script type=\"text/javascript\">

alert('Your form filling has been mailed. please come to our office for further process. Thank you for your booking.');

window.location='http://app-1529770455.000webhostapp.com/booking.html'

</script>";

?>