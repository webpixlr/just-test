<?php
error_reporting(0);
// download fpdf class (http://fpdf.org)
require("../fpdf/fpdf.php");

$plotsize=$_REQUEST['plotsize'];
$plotno=$_REQUEST['plotno'];
$name=$_REQUEST['name'];
$sec_appli=$_REQUEST['sec_appli'];
$sec_son=$_REQUEST['sec_son'];
$address=$_REQUEST['address'];
$nominee=$_REQUEST['nominee'];
$state=$_REQUEST['state'];
$pincode=$_REQUEST['pincode'];
$phone=$_REQUEST['phone'];
$mobile=$_REQUEST['mobile'];
$statusRadios=$_POST['statusRadios'];
$individRadios=$_POST['individRadios'];
$occuRadios=$_POST['occuRadios'];




?>