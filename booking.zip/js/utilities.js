var generateAttachment = function(uriString, fileName){
  var uristringparts = uriString.split(',');
  uristringparts[0] = "base64:" + fileName + "//";
  return uristringparts.join("");
};