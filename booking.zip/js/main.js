 var pdfString = doc.output('datauristring'); //base64 string from jsPDF

if (window.cordova && window.cordova.plugins.email) {

  var email = {
      to: 'simadev75@gmail.com',
      //cc: 'jdnichollsc@hotmail.com',
      //bcc: ['jdnichollsc@hotmail.com'],
      attachments: [
          generateAttachment(pdfString, "myFileName.pdf")
      ],
      subject: 'Mira un PDF!',
      body: 'Abre el PDF creado con jsPDF :)',
      isHtml: true
  };

  cordova.plugins.email.open(email);

}