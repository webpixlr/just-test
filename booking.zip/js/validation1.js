// JavaScript Document

function validation(){

	var i= "";

	// RegEx

	var name_check = /^[A-Za-z ]{3,40}$/; // Name Check
	var phone_check = /^[789][0-9]{9}$/;
	var number = /^[0-9]$/;
	
	
	// ********************** Plot Size **************************
	
	
	
	
	
	

	// ****************** Applicant Name  *************************
	
	var fname = document.getElementById('fname').value;
	
	if(fname != "")
		{
			document.getElementById('name_span').innerHTML=" ";					
		}
	else
		{
			document.getElementById('name_span').innerHTML=" ** Please enter Your Name";
			return false;
		}

		if(name_check.test(fname))
		{
			document.getElementById('name_span').innerHTML="";	
		}

		else
		{
			document.getElementById('name_span').innerHTML=" ** Name field is invalid";
			return false;
		}

		if((fname.length <=2) || (fname.length>40))
			{
				document.getElementById('name_span').innerHTML="Name must be between 2 and 40";
				return false;
			}




	// ***************** Second Applicant Name  **********************************
	
	var ssappli = document.getElementById('ssappli').value;

	if(ssappli != "")
		{
			document.getElementById('appliname_span').innerHTML=" ";					
		}
	else
		{
			document.getElementById('appliname_span').innerHTML=" ** Please enter Second Applicant Name";
			return false;
		}

		if(name_check.test(ssappli))
		{
			document.getElementById('appliname_span').innerHTML="";	
		}

		else
		{
			document.getElementById('appliname_span').innerHTML=" ** Second Applicant Name field is invalid";
			return false;
		}

		if((ssappli.length <=2) || (ssappli.length>40))
			{
				document.getElementById('appliname_span').innerHTML="Second Applicant Name must be between 2 and 40";
				return false;
			}




	// ***************** S/O D/O W/O  **********************************
	
	var sson = document.getElementById('sson').value;

	if(sson != "")
		{
			document.getElementById('sson_span').innerHTML=" ";					
		}
	else
		{
			document.getElementById('sson_span').innerHTML=" ** Please enter S/O D/O W/O";
			return false;
		}

		if(name_check.test(sson))
		{
			document.getElementById('sson_span').innerHTML="";	
		}

		else
		{
			document.getElementById('sson_span').innerHTML=" ** S/O D/O W/O field is invalid";
			return false;
		}

		if((sson.length <=2) || (sson.length>40))
			{
				document.getElementById('sson_span').innerHTML="S/O D/O W/O must be between 2 and 40";
				return false;
			}



	// ***************** Address **********************************
	
	var faddr= document.getElementById('faddr').value;

	if(faddr != "")
		{
			document.getElementById('faddr_span').innerHTML=" ";					
		}
	else
		{
			document.getElementById('faddr_span').innerHTML=" ** Please enter Your Address";
			return false;
		}






	// ***************** Nominee  **********************************

	var fnominee = document.getElementById('fnominee').value;
	
	if(fnominee != "")
		{
			document.getElementById('fnominee_span').innerHTML=" ";					
		}
	else
		{
			document.getElementById('fnominee_span').innerHTML=" ** Please enter Nominee";
			return false;
		}

		if(name_check.test(fnominee))
		{
			document.getElementById('fnominee_span').innerHTML="";	
		}

		else
		{
			document.getElementById('fnominee_span').innerHTML=" ** Nominee field is invalid";
			return false;
		}

		if((fnominee.length <=2) || (fnominee.length>40))
			{
				document.getElementById('fnominee_span').innerHTML="Nominee must be between 2 and 40";
				return false;
			}




	// ***************** State  **********************************
	
	var fstate = document.getElementById('fstate').value;

	if(fstate != "")
		{
			document.getElementById('fstate_span').innerHTML=" ";					
		}
	else
		{
			document.getElementById('fstate_span').innerHTML=" ** Please enter State";
			return false;
		}

		if(name_check.test(fstate))
		{
			document.getElementById('fstate_span').innerHTML="";	
		}

		else
		{
			document.getElementById('fstate_span').innerHTML=" ** State field is invalid";
			return false;
		}

		if((fstate.length <=2) || (fstate.length>40))
			{
				document.getElementById('fstate_span').innerHTML="State must be between 2 and 40";
				return false;
			}




	// ***************** Pincode **********************************

	var fpincode = document.getElementById('fpincode').value;
	
	if(fpincode != "")
		{
			document.getElementById('fpincode_span').innerHTML=" ";					
		}
	else
		{
			document.getElementById('fpincode_span').innerHTML=" ** Please enter Pincode";
			return false;
		}

		if(name_check.test(fstate))
		{
			document.getElementById('fpincode_span').innerHTML="";	
		}

		else
		{
			document.getElementById('fpincode_span').innerHTML=" ** Pincode field is invalid";
			return false;
		}

		if((fpincode.length <=2) || (fpincode.length>20))
			{
				document.getElementById('fpincode_span').innerHTML="Pincode must be between 2 and 20";
				return false;
			}


	// ***************** Phone **********************************
	
	//var fphone = document.getElementById('fphone').value;
	//if(fphone == "")
//		{
//			document.getElementById('fphone_span').innerHTML=" ";	
//			return false;
//		}
//
	 //if(phone_check.test(fphone))
//		{
//			document.getElementById('fphone_span').innerHTML="";
//			return true;
//		}
//
//		
//			document.getElementById('fphone_span').innerHTML="** Enter valid Phone Number ";
//			return false;
//		


	// ***************** Mobile **********************************
	
	var fmobile = document.getElementById('fmobile').value;
	
	if(fmobile != "")
		{
			document.getElementById('fmobile_span').innerHTML=" ";			
		}
	
	else
		{
			document.getElementById('fmobile_span').innerHTML="** Enter Mobile Number";
			return false;
		}

	if(phone_check.test(fmobile))
		{
			document.getElementById('fmobile_span').innerHTML="";	
		}

		else
		{
			document.getElementById('fmobile_span').innerHTML="** Enter valid Mobile Number";
			return false;
		}


	// *********************** Status *************************
		
		
	
	
	
		

	// *********************** Occupation *************************
		
		var foccuradios	= document.frm.occuRadios;

		  



	// *********************** In case of Individual *************************
		
		var findividradios = document.frm.individRadios;
	
	
	