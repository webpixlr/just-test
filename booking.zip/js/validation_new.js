// JavaScript Document


	
	
	$(document).ready(function(){
  $('#btnSubmit').click(function() {
    if (!$("input[name='statusRadios']:checked").val()) {
        document.getElementById('fstatus_span').innerHTML="** Please select a Status";
        return false;
    }
    else {
      document.getElementById('fstatus_span').innerHTML="";
    }
  });
});
	
	$(document).ready(function(){
  $('#btnSubmit').click(function() {
    if (!$("input[name='occuRadios']:checked").val()) {
        document.getElementById('foccuradios_span').innerHTML="** Please select Occupation";
        return false;
    }
    else {
      document.getElementById('foccuradios_span').innerHTML="";
    }
  });
});
	
$(document).ready(function(){
	$('#btnSubmit').click(function() {
		var statusb=$("input[name='statusRadios']:checked").val();
		if(statusb =='Individual')
		{
			if (!$("input[name='individRadios']:checked").val())
				{
					document.getElementById('findividradios_span').innerHTML="** Please select In case of Individual";	
					return false;
				}
			else
			{
				document.getElementById('findividradios_span').innerHTML="";
			}
		}
	});

});