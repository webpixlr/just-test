function validation(){
			var name = document.getElementById('name').value;
			var phone = document.getElementById('phone').value;
			var email = document.getElementById('email').value;
			var message = document.getElementById('message').value;
			
			// Valid Check 
			
			var name_check = /^[A-Za-z ]{3,30}$/; // Name Check
			var email_check = /^[A-Za-z_]{2,}@[A-Za-z]{3,}[.]{1}[A-Za-z.]{2,6}$/; // Email Check
			var phone_check = /^[789][0-9]{9}$/;
 			
			// Name 
			
			if(name != "")
				{
					document.getElementById('name_span').innerHTML=" ";					
				}
			else
				{
					document.getElementById('name_span').innerHTML=" ** Please enter Your Name";
					return false;
				}
			
				if(name_check.test(name))
				{
					document.getElementById('name_span').innerHTML="";	
				}
			
				else
				{
					document.getElementById('name_span').innerHTML=" ** Name field is invalid";
					return false;
				}
			
			    if((name.length <=2) || (name.length>35))
					{
						document.getElementById('name_span').innerHTML="Name must be between 2 and 35";
						return false;
					}
		
			
			
			
			if(phone != "")
				{
					document.getElementById('phone_span').innerHTML=" ";					
				}
			else
			{
					document.getElementById('phone_span').innerHTML=" ** Please enter Your Phone Number";
					return false;
			
			}
				
			if(phone_check.test(phone))
				{
					document.getElementById('phone_span').innerHTML="";	
				}
			
				else
				{
					document.getElementById('phone_span').innerHTML=" ** Enter valid Phone Number ";
					return false;
				}
			
			if((phone.length < 10))
					{
						document.getElementById('name_span').innerHTML="Name must be 10 digits";
						return false;
					}
			
			
			// Email 
			
			 if(email != "")
				{
					document.getElementById('email_span').innerHTML=" ";
				}
	
			else
			{
					document.getElementById('email_span').innerHTML=" ** Please enter Your Email";
					return false;		
			}
			
			
			 if (email_check.test(email)) {
				document.getElementById('email_span').innerHTML=" ";								
			 }
			else
				{
					document.getElementById('email_span').innerHTML=" ** Please provide a valid email address ";
					email.focus;
					return false;
				}
	
	
			// Mesasge
			
			if(message != "")
				{
					document.getElementById('message_span').innerHTML=" ";					
				}
			else
				{
					document.getElementById('message_span').innerHTML=" ** Please enter Message";
					return false;
				}
			 
		}